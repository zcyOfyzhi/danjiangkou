import Input from "./src/component/Input";
import ButtonView from "./src/component/ButtonView";
import Paper from "./src/component/Paper";
import StatusView from "./src/component/StatusView";
import TextView from "./src/component/TextView";
import SetStatusBar from "./src/component/SetStatusBar";
import Header from "./src/component/Header";

module.exports = {
    TextView,
    Input,
    ButtonView,
    Paper,
    StatusView,
    SetStatusBar,
    Header,
};