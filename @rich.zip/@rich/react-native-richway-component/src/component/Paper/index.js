import Paper from './Paper';

export default Paper;
