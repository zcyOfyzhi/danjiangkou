const BaseStyle = {
  themeColor:'#128DE9',
  textItemColor: '#9c9a9d',
  valueItemColor: '#656165',
};
export default BaseStyle;
