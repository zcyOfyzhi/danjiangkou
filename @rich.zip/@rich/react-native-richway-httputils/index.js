import HttpUtils from './HttpUtils'

export default HttpUtils;
